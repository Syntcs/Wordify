import SwiftUI
import SwiftData



@Model
class vListe {
    var id: UUID
    var vokabelL: String
    var vokabelR: String
    
    init(vokabelL: String, vokabelR: String) {
        self.id = UUID()
        self.vokabelL = vokabelL
        self.vokabelR = vokabelR
    }
}

@Model
class Liste {
    var id: UUID
    var name: String
    var datum: Date
    @Relationship(deleteRule: .cascade) var liste: [vListe]
    
    init(name: String, datum: Date) {
        self.id = UUID()
        self.name = name
        self.liste = []
        self.datum = datum
    }
}

struct Bibliothek: View {
    @Query private var liste: [Liste]
    @State private var sortingSelection = "A-Z"

    var sortedListe: [Liste] {
        switch sortingSelection {
        case "A-Z":
            return liste.sorted { $0.name < $1.name }
        case "Datum":
            return liste.sorted { $0.datum < $1.datum }
        default:
            return liste
        }
    }
    
    @Environment(\.modelContext) private var modelContext
    
    
    @State var datum = ""
    @State private var selectedDate = Date()
    @State private var showingPopover = false
    @State private var showingDetailPopover = false
    @State private var listName = ""
    @State private var searchText = ""

    @State private var notification = false
    @FocusState var isFocs: Bool
    
    var repeatNotification = ["Täglich", "Wöchentlich", "Monatlich", "Jährlich"]
    var SortingOptions = ["A-Z", "Datum"]
    

    
    @State private var notificationTime = Date()
    @State var repeatNotificationAuswahl = "Täglich"
    
    var body: some View {
        NavigationView {
            VStack {
                Picker("Sortieren nach:", selection: $sortingSelection){
                    ForEach(SortingOptions, id: \.self) {
                        SortingOptions in Text(SortingOptions)
                    }
                }.pickerStyle(.palette).padding(.horizontal, 20)
                List(sortedListe.filter {
                    searchText.isEmpty || $0.name.localizedCaseInsensitiveContains(searchText)
                }) { liste in
                    NavigationLink(destination: vokabelListe(liste: liste)) {
                        VStack(alignment: .leading) {
                            Text(liste.name)
                                .font(.system(size: 25))
                                .foregroundColor(.black)
                                .swipeActions {
                                    Button("Löschen", role: .destructive) {
                                        modelContext.delete(liste)
                                    }
                                    Button(action: {
                                        showingDetailPopover = true
                                    }, label: {
                                        Text("Details")
                                    }).tint(.blue)
                                }
                            HStack{
                                Text("Testdatum:")
                                    .font(.system(size: 15))
                                    .foregroundColor(.black)
                                Text(DateFormatter.localizedString(from: liste.datum, dateStyle: .medium, timeStyle: .none))
                                    .environment(\.locale, Locale(identifier: "de_DE"))
                                    .font(.system(size: 15))
                                    .foregroundColor(.black)
                            }
                            /*HStack(){
                             Text("[Tag]")
                             .font(.system(size: 12))
                             .foregroundColor(.black)
                             .padding(EdgeInsets(top: 2, leading: 5, bottom: 2, trailing: 5))
                             .background(Color.green.cornerRadius(4))
                             }*/
                        }
                    }.foregroundStyle(Color.black)
                        .listRowBackground(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.black, lineWidth: 0)
                                .background(Color(red: 0.9, green: 0.9, blue: 0.9)
                                    .cornerRadius(8)
                                )
                                .padding(EdgeInsets(top: 3, leading: 5, bottom: 3, trailing: 5))
                        )
                        .listRowSeparator(.hidden)
                }
                .padding(.horizontal, 15)
                .navigationTitle("Bibliothek")
                .listStyle(.inset)
                .searchable(text: $searchText)
                
                Spacer()
                Button(action: {
                    showingPopover = true
                }, label: {
                    Spacer()
                    Image(systemName: "plus")
                        .padding(15)
                        .font(.system(size: 30))
                        .background(Color.blue)
                        .foregroundColor(Color.white)
                        .clipShape(Circle())
                }).frame(maxWidth: .infinity, alignment: .trailing).padding(.horizontal, 15)
                
                Divider()
            }
            
        }
        .popover(isPresented: $showingPopover) {
            ZStack {
                VStack{
                    VStack {
                        Text("Vokabelliste erstellen")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(20)
                            .font(.largeTitle)
                            .bold(true)
                        
                        VStack {
                            Text("Gib der Liste einen Namen")
                                .font(.title3)
                                .bold()
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.leading, 10)
                            
                            TextField("Name", text: $listName)
                                .font(.system(size: 25))
                                .bold()
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.leading, 10)
                            
                        }
                    }
                    
                    VStack {
                        Text("Wann ist das Prüfungsdatum?")
                            .font(.title3)
                            .bold()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 10)
                        DatePicker("", selection: $selectedDate, displayedComponents: .date)
                            .labelsHidden()
                            .environment(\.locale, Locale(identifier: "de_DE"))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 10)
                        
                        Text("MITTEILUNGEN")
                            .font(.footnote)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 10)
                            .padding(.top, 10)
                            .foregroundStyle(Color.gray)
                        VStack {
                            List {
                                HStack {
                                    Image(systemName: "bell.square.fill")
                                        .font(.title)
                                        .foregroundStyle(Color.red)
                                    Toggle("Lernerinnerungen", isOn: $notification)
                                }
                            }.frame(maxHeight: 50).contentMargins(.top, 7)
                            List {
                                if notification {
                                    HStack {
                                        ZStack {
                                            Image(systemName: "square.fill")
                                                .font(.title)
                                                .foregroundStyle(Color.blue)
                                            Image(systemName: "repeat")
                                                .foregroundStyle(Color.white)
                                        }
                                        Picker("Häufigkeit", selection: $repeatNotificationAuswahl) {
                                            ForEach(repeatNotification, id: \.self) {
                                                repeatNotification in Text(repeatNotification)
                                                
                                            }
                                        }.focused($isFocs)
                                    }
                                    HStack {
                                        VStack {
                                            HStack {
                                                ZStack {
                                                    Image(systemName: "square.fill")
                                                        .font(.title)
                                                        .foregroundStyle(Color.black)
                                                    Image(systemName: "clock.fill")
                                                        .foregroundStyle(Color.white)
                                                }
                                                Text("Uhrzeit")
                                            }.frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 5)
                                            
                                            DatePicker("Uhrzeit", selection: $notificationTime, displayedComponents: .hourAndMinute)
                                                .labelsHidden()
                                                .datePickerStyle(.wheel)
                                        }
                                    }
                                }
                            }.listRowBackground(Color.red).listStyle(.insetGrouped).frame(maxHeight: 350).contentMargins(.top, 5)
                        }.background(Color("lightgray"))
                        Spacer()
                    }
                    Button("Hinzufügen") {
                        let insert = Liste(name: listName, datum: selectedDate)
                        modelContext.insert(insert)
                        listName = ""
                        
                        showingPopover = false
                    }.padding(20)
                        .font(.system(size: 20))
                        .bold(true)
                        .background(Color.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .foregroundStyle(Color.white)
                }
            }
        }
        
        .popover(isPresented: $showingDetailPopover) {
            //ListDetail(ListenName: Liste)
            /*NavigationLink(destination: ListDetail(liste: Liste), label: {
                Text("Test")
            })*/
            /*
            ZStack {
                VStack{
                    VStack {
                        Text("Vokabelliste erstellen")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(20)
                            .font(.largeTitle)
                            .bold(true)
                        
                        VStack {
                            Text("Gib der Liste einen Namen")
                                .font(.title3)
                                .bold()
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.leading, 10)
                            
                            TextField("\(sortedListe.first?.name ?? "")", text: $listName)
                                .font(.system(size: 25))
                                .bold()
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.leading, 10)
                            
                        }
                    }
                    
                    VStack {
                        Text("Wann ist das Prüfungsdatum?")
                            .font(.title3)
                            .bold()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 10)
                        DatePicker("", selection: $selectedDate, displayedComponents: .date)
                            .labelsHidden()
                            .environment(\.locale, Locale(identifier: "de_DE"))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 10)
                        
                        Text("MITTEILUNGEN")
                            .font(.footnote)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 10)
                            .padding(.top, 10)
                            .foregroundStyle(Color.gray)
                        VStack {
                            List {
                                HStack {
                                    Image(systemName: "bell.square.fill")
                                        .font(.title)
                                        .foregroundStyle(Color.red)
                                    Toggle("Lernerinnerungen", isOn: $notification)
                                }
                            }.frame(maxHeight: 50).contentMargins(.top, 7)
                            List {
                                if notification {
                                    HStack {
                                        ZStack {
                                            Image(systemName: "square.fill")
                                                .font(.title)
                                                .foregroundStyle(Color.blue)
                                            Image(systemName: "repeat")
                                                .foregroundStyle(Color.white)
                                        }
                                        Picker("Häufigkeit", selection: $repeatNotificationAuswahl) {
                                            ForEach(repeatNotification, id: \.self) {
                                                repeatNotification in Text(repeatNotification)
                                                
                                            }
                                        }.focused($isFocs)
                                    }
                                    HStack {
                                        VStack {
                                            HStack {
                                                ZStack {
                                                    Image(systemName: "square.fill")
                                                        .font(.title)
                                                        .foregroundStyle(Color.black)
                                                    Image(systemName: "clock.fill")
                                                        .foregroundStyle(Color.white)
                                                }
                                                Text("Uhrzeit")
                                            }.frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 5)
                                            
                                            DatePicker("Uhrzeit", selection: $notificationTime, displayedComponents: .hourAndMinute)
                                                .labelsHidden()
                                                .datePickerStyle(.wheel)
                                        }
                                    }
                                }
                            }.listRowBackground(Color.red).listStyle(.insetGrouped).frame(maxHeight: 350).contentMargins(.top, 5)
                        }.background(Color("lightgray"))
                        Spacer()
                    }
                    Button("Hinzufügen") {
                        let insert = Liste(name: listName, datum: selectedDate)
                        modelContext.insert(insert)
                        listName = ""
                        
                        showingPopover = false
                    }.padding(20)
                        .font(.system(size: 20))
                        .bold(true)
                        .background(Color.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .foregroundStyle(Color.white)
                }
            }*/
        }
    }
}

struct ListDetail: View {
    @Bindable var liste: Liste
    
    var body: some View {
        TextField("Text", text: $liste.name)
    }
}


#Preview {
    Bibliothek()
        .modelContainer(for: [Liste.self, vListe.self], inMemory: true)
}
