//
//  mainSide.swift
//  VocabHub
//
//  Created by Lukas Riethig on 22.09.23.
//

import SwiftUI

struct mainSide: View {

    @State var isFirstTime = true
    @State var hasShownTutorial = ""
    
    var body: some View {
        NavigationView {
            VStack{
                TabView {
                    translateSide()
                        .tabItem {
                            Text("Start")
                            Image(systemName: "house.fill")
                        }
                    
                    Lernspiele()
                        .tabItem {
                            Text("Lernen")
                            Image(systemName: "graduationcap.fill")
                        }
                    Bibliothek()
                        .tabItem {
                            Text("Bibliothek")
                            Image(systemName: "books.vertical.fill")
                        }
                    /*Settings()
                        .tabItem {
                            Text("Einstellungen")
                            Image(systemName: "gearshape")
                        }*/
                }.accentColor(.blue)
                
            }

        }
        
    }
}

#Preview {
    mainSide()
}
