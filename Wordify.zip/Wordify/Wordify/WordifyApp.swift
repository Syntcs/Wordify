import SwiftUI
import SwiftData
@main
struct WordifyApp: App {
    @State var tutorialshown = false
    
    var body: some Scene {
        WindowGroup {
                mainSide()
                    .modelContainer(for: Liste.self)
                    .onAppear {
                        let erinnerung = Erinnerungsfunktion()
                        erinnerung.checkForPermission()
                    }
        }
    }
}
