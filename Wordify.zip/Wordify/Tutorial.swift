import SwiftUI

struct tutorialseite {
    let title: String
    let description: String
    let image: String
}

private let tutorialseiten = [
    tutorialseite(title: "Willkommen in Wordify", description: "", image: "Vokabel"),
    
    tutorialseite(title: "Bestätigen", description: "Drücke auf den Pfeil um zu Übersetzen", image: "Startseite Knopf"),
    
    tutorialseite(title: "Sprache umstellen", description: "Hier kannst du deine gewünschte Sprache einstellen in die du Übersetzen willst", image: "Startseite Sprache"),
    
    tutorialseite(title: "Favorisieren", description: "Hier kannst du das Oben eingetragene Wort oder den Satz Speichern", image: "Startseite Favorisieren"),
    
    tutorialseite(title: "Sprachausgabe", description: "Aktiviere es und lasse dir das Übersetzte aussprechen", image: "Startseite Sprachausgabe"),
    
    tutorialseite(title: "Trainiere um besser zu werden", description: "Hier gibt es eine Auswahl an Lernspielen die beim Lernen auch ein Spaßfaktor mit sich bringt ", image: "Lernspiele"),
    
    tutorialseite(title: "Speichere deine Aufgaben", description: "Hast du demnächst ein Vokabeltest? Hier kannst du die Wörter die gelernt werden müssen eintragen und Speichern", image: "Bibliothek")
]

struct Tutorial: View {
    @State private var currentstep = 0
    var index: Int
    
    init(index: Int) {
        UIScrollView.appearance().bounces = false
        self.index = index
    }
    var body: some View {
        NavigationStack {
            VStack{
                HStack{
                    Spacer()
                    Button(action: {
                        self.currentstep = tutorialseiten.count - 1
                    }){
                        Text("Überspringen")
                            .padding(16)
                            .foregroundColor(.gray)
                    }
                }
                
                TabView(selection: $currentstep){
                    ForEach(0..<tutorialseiten.count) { it in
                        
                        VStack{
                            
                            Image(tutorialseiten[it].image)
                                .resizable()
                                .scaledToFit()
                            
                            
                            
                            Text(tutorialseiten[it].title)
                                .font(.title)
                                .bold()
                            
                            Text(tutorialseiten[it].description)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 32)
                                .padding(.top, 16)
                        }
                        .tag(it)
                    }
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                
                HStack{
                    ForEach(0..<tutorialseiten.count) { it in
                        if it == currentstep {
                            Circle()
                                .frame(width: 20, height: 10)
                                .cornerRadius(10)
                                .foregroundColor(.blue)
                        } else {
                            Circle()
                                .frame(width: 20, height: 10)
                                .foregroundColor(.gray)
                        }
                    }
                }
                .padding(.bottom)
                if currentstep < 6 {
                    Button(action:{
                        if self.currentstep < tutorialseiten.count - 1 {
                            self.currentstep += 1
                            print(currentstep)
                        }
                        
                    }) {
                        Text("Nächste Seite")
                            .padding(16)
                            .frame(maxWidth: .infinity)
                            .background(Color.blue)
                            .cornerRadius(16)
                            .padding(.horizontal, 16)
                            .foregroundColor(.white)
                    }
                    .buttonStyle(PlainButtonStyle())
                } else {
                    Button(action: {
                        //self.backButtonHidden = true
                    }, label: {
                        NavigationLink(destination: mainSide(), label: {
                            Text("Los geht's")
                                .padding(16)
                                .frame(maxWidth: .infinity)
                                .background(Color.blue)
                                .cornerRadius(16)
                                .padding(.horizontal, 16)
                                .foregroundColor(.white)
                        })
                    })
                    
                }
            }
        }
    }
}
#Preview {
    Tutorial(index: 1)
}
