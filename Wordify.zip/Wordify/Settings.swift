import SwiftUI

struct Settings: View {
    @State private var tutorial = false
    @State private var darkmode = false
    @State private var pushbenachrichtigung = false
    var Sprachen = ["Deutsch", "Englisch", "Spanisch", "Französisch"]
    @AppStorage("Sprache") private var Sprache = "Englisch"
    var Hintergrundeinstellung = ["Light Mode", "Dark Mode", "Systemeinstellung"]
    @AppStorage("isDarkMode") private var isDarkMode = false

    
    var body: some View {
            VStack{
                Text("Einstellungen")
                    .font(.largeTitle)
                    .bold()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(15)
                    Text("STANDARDEINSTELLUNGEN")
                        .font(.footnote)
                        .padding(.trailing, 170)
                        .padding(.top, 10)
                        .foregroundStyle(Color.gray)
                        List {
                            HStack{
                                ZStack {
                                    Image(systemName: "square.fill")
                                        .font(.title)
                                        .foregroundStyle(Color.yellow)
                                    Image(systemName: "sun.max.fill")
                                        .foregroundStyle(Color.white)
                                }
                                Toggle("Dunkelmodus", isOn: $isDarkMode).preferredColorScheme(isDarkMode ? .dark : .light)
                            }
                            
                            HStack{
                                ZStack {
                                    Image(systemName: "square.fill")
                                        .font(.title)
                                        .foregroundStyle(Color.green)
                                    Image(systemName: "globe")
                                        .foregroundStyle(Color.white)
                                }
                                Picker("Standardsprache", selection: $Sprache) {
                                    ForEach(Sprachen, id: \.self) {
                                        Sprachen in Text(Sprachen)
                                    }
                                }
                                .pickerStyle(.navigationLink)
                            }
                        }.listStyle(.grouped).contentMargins(.top, 0).frame(maxHeight: 89.1)
                        Spacer()
            }.frame(maxWidth: .infinity, maxHeight: .infinity)
                .frame(height: 300)
                .background(Color("darkmodeBackground"))
                .clipShape(.rect(cornerRadius: 25))
                .padding(.horizontal, 15)
            }
        }




#Preview {
    Settings()
}
