import SwiftUI

struct translateTest: View {
    @State private var inputText = ""
    @State private var translatedText = ""
    let apiKey = "4c77e0fc-db3a-acc1-3882-be1e757d243c:fx"
    let targetLanguage = "ES"

    var body: some View {
        VStack {
            NavigationStack {
                TextField("Text eingeben", text: $inputText)
                    .navigationTitle("Wordify")
                    .font(.system(size: 25))
                    .padding(.leading, 20)
                    .padding(.top, 10)
                    .frame(height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                
                Spacer()
                
                Button(action: {
                    translateText()
                }, label: {
                    Text("Übersetzen")
                        .padding(15)
                        .font(.system(size: 20))
                        .background(.blue)
                        .foregroundStyle(Color.white)
                        .clipShape(RoundedRectangle(cornerRadius: 25))
                        
                        
                })
                
                Divider()
                
                Text("Übersetzung: \(translatedText)")
            }
            
        }
        
    }

    func translateText() {
        if apiKey.isEmpty {
            print("DeepL API-Schlüssel fehlt.")
            return
        }

        let endpoint = "https://api-free.deepl.com/v2/translate"
        let authHeader = "DeepL-Auth-Key \(apiKey)"
        let textParameter = "text=\(inputText.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")"
        let targetLangParameter = "target_lang=\(targetLanguage)"

        guard let url = URL(string: endpoint) else {
            print("Ungültige URL.")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue(authHeader, forHTTPHeaderField: "Authorization")
        request.httpBody = "\(textParameter)&\(targetLangParameter)".data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Fehler bei der Anfrage: \(error.localizedDescription)")
            } else if let data = data {
                do {
                    let decodedResponse = try JSONDecoder().decode(DeepLResponse.self, from: data)
                    translatedText = decodedResponse.translations.first?.text ?? "Übersetzung nicht verfügbar"
                } catch {
                    print("Fehler beim Dekodieren der API-Antwort: \(error.localizedDescription)")
                }
            }
        }.resume()
    }
}

struct DeepLResponse: Decodable {
    struct Translation: Decodable {
        var detected_source_language: String
        var text: String
    }

    var translations: [Translation]
}

struct translateTest_Previews: PreviewProvider {
    static var previews: some View {
        translateTest()
    }
}
