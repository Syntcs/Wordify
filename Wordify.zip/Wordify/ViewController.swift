//
//  ViewController.swift
//  Wordify
//
//  Created by Lukas Riethig on 01.12.23.
//

import Foundation
import AVFoundation

class ViewController: UIViewController{
    override func viewDidLoad(){
        super.viewDidLoad()
        

    }
}
