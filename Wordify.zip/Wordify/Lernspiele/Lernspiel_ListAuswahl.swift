//
//  Lernspiel_ListAuswahl.swift
//  Wordify
//
//  Created by Lukas Riethig on 30.01.24.
//

import SwiftUI
import SwiftData

struct Lernspiel_ListAuswahl: View {
    
    
    
    var index: Int
    
    init(index: Int) {
        self.index = index
    }
    
    @Query(sort: \Liste.name) private var inhalt: [Liste]
    @Query private var liste: [Liste]
    
    var body: some View {
        NavigationStack {
            VStack (alignment: .leading){
                Text("Lernspiele")
                    .font(.largeTitle)
                    .bold(true)
                    .padding(.leading, 15)
                    List {
                        ForEach(inhalt) { liste in
                            NavigationLink(destination: RichtigOderFalsch(liste: liste), label: {
                                
                            })
                            VStack(alignment: .leading) {
                                Text(liste.name)
                                    .font(.system(size: 25))
                                    .foregroundColor(.black)
                                HStack(){
                                    Text("[Tag]")
                                        .font(.system(size: 12))
                                        .foregroundColor(.black)
                                        .padding(EdgeInsets(top: 2, leading: 5, bottom: 2, trailing: 5))
                                        .background(Color.gray.cornerRadius(4))
                                    Text("[Tag]")
                                        .font(.system(size: 12))
                                        .foregroundColor(.black)
                                        .padding(EdgeInsets(top: 2, leading: 5, bottom: 2, trailing: 5))
                                        .background(Color.green.cornerRadius(4))
                                    Text("[Tag]")
                                        .font(.system(size: 12))
                                        .foregroundColor(.black)
                                        .padding(EdgeInsets(top: 1, leading: 5, bottom: 2, trailing: 5))
                                        .background(Color.red.cornerRadius(4))
                                }
                            }
                            .listRowBackground(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 0)
                                    .background(Color(red: 0.9, green: 0.9, blue: 0.9)
                                        .cornerRadius(8)
                                    )
                                    .padding(EdgeInsets(top: 3, leading: 5, bottom: 3, trailing: 5))
                            )
                            .listRowSeparator(.hidden)
                        }
                    }.padding(.horizontal, 15)
                        .listStyle(.inset).frame(maxHeight: 350)
                        .contentMargins(.bottom, 0)
                
                Divider()
            
                if index==1 {
                    Text("Richtig oder Falsch")
                        .bold(true)
                        .font(.system(size: 30))
                        .padding(.leading, 15)
                    
                    
                    Text("Wähle zuerst eine Vokabelliste aus, mit welcher du \ndas Lernspiel ausführen möchtest.\n\nIm laufe des Spiels, gehst du alle Vokabeln der ausgewählten Liste durch. \nEs wird jeweils eine Vokabel und eine Übersetzung angezeigt.\nDiese sind möglicherweise nicht immer richtig.\nHier kommst du ins Spiel du musst auswählen, ob die Übersetzung richtig oder falsch ist.")
                        .padding(.leading, 15)
                    
                    Spacer()
                    
                    NavigationLink(destination: {
                        RichtigOderFalsch(liste: liste)
                    }, label: {
                        HStack {
                            Spacer()
                            Image(systemName: "arrow.right.circle.fill")
                                .foregroundStyle(Color.blue)
                                .font(.system(size: 50))
                                .padding(.trailing, 20)
                                .padding(.top, 5)
                        }
                    })//.navigationTitle("Richtig oder Falsch")
                    
                    Spacer()
                }
                if index==2 {
                    Text("Lückenspiel")
                        .bold(true)
                        .font(.system(size: 30))
                        .padding(.leading, 15)
                    
                    
                    Text("Wähle zuerst eine Vokabelliste aus, mit welcher du \ndas Lernspiel ausführen möchtest.\n\nDu erhälst anschließend ein Wort und dessen passende Übersetzung.\nDie Übersetzung ist jedoch lückenhaft.\nDu musst du Lücken mit den richtigen Buchstaben füllen.")
                        .padding(.leading, 15)
                    
                    Spacer()
                    
                    NavigationLink(destination: {
                        Lueckenspiel()
                    }, label: {
                        HStack {
                            Spacer()
                            Image(systemName: "arrow.right.circle.fill")
                                .foregroundStyle(Color.blue)
                                .font(.system(size: 50))
                                .padding(.trailing, 20)
                                .padding(.top, 5)
                        }
                    })//.navigationTitle("Lückenspiel")
                    
                    Spacer()
                }
                if index==3 {
                    Text("Multiple Choice")
                        .bold(true)
                        .font(.system(size: 30))
                        .padding(.leading, 15)
                    
                    
                    Text("Wähle zuerst eine Vokabelliste aus, mit welcher du \ndas Lernspiel ausführen möchtest.\n\nIn diesem Spiel hast du jedes Vokabelpaar aus der von dir ausgewählten Liste. Diese sind vermischt.\nDu hast die Aufgabe die Paare richtig zusammenzusetzen.")
                        .padding(.leading, 15)
                    
                    Spacer()
                    
                    NavigationLink(destination: {
                        RichtigOderFalsch()
                    }, label: {
                        HStack {
                            Spacer()
                            Image(systemName: "arrow.right.circle.fill")
                                .foregroundStyle(Color.blue)
                                .font(.system(size: 50))
                                .padding(.trailing, 20)
                                .padding(.top, 5)
                        }
                    })//.navigationTitle("Multiple Choice")
                    
                    Spacer()
                }
                if index==4 {
                    Text("Zeitspiel")
                        .bold(true)
                        .font(.system(size: 30))
                        .padding(.leading, 15)
                    
                    
                    Text("Wähle zuerst eine Vokabelliste aus, mit welcher du \ndas Lernspiel ausführen möchtest.\n\nDu hast dann 4 Wörter zur Auswahl.\nEins dieser Wörter ist die korrekte Übersetzung. Die korrekte Übersetzung musst du innerhalb von 3 Sekunden finden. Anschließend geht es weiter. \nKannst du rechtzeitig die richtige Übersetzung finden?")
                        .padding(.leading, 15)
                    
                    Spacer()
                    
                    NavigationLink(destination: {
                        RichtigOderFalsch()
                    }, label: {
                        HStack {
                            Spacer()
                            Image(systemName: "arrow.right.circle.fill")
                                .foregroundStyle(Color.blue)
                                .font(.system(size: 50))
                                .padding(.trailing, 20)
                                .padding(.top, 5)
                        }
                    })//.navigationTitle("Zeitspiel")
                    
                    Spacer()
                }
                if index==5 {
                    Text("Vokabeltest")
                        .bold(true)
                        .font(.system(size: 30))
                        .padding(.leading, 15)
                    
                    
                    Text("Wähle zuerst eine Vokabelliste aus, mit welcher du \ndas Lernspiel ausführen möchtest.\n\nHier wird jede Vokabel nach und nach aus der Liste abgefragt. Du musst ohne Hilfen die passende Übersetzung vollständig fehlerfrei eingeben. \nAm Ende hast du eine Punktzahl und eine Note (1-6).")
                        .padding(.leading, 15)
                    
                    Spacer()
                    
                    NavigationLink(destination: {
                        RichtigOderFalsch()
                    }, label: {
                        HStack {
                            Spacer()
                            Image(systemName: "arrow.right.circle.fill")
                                .foregroundStyle(Color.blue)
                                .font(.system(size: 50))
                                .padding(.trailing, 20)
                                .padding(.top, 5)
                        }
                    })
                    
                    Spacer()
                }
            }.navigationBarBackButtonHidden(false)
        }
    }
}



#Preview {
    Lernspiel_ListAuswahl(index: 5)
}
