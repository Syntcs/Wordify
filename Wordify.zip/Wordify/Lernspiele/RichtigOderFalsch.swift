//
//  RichtigOderFalsch.swift
//  Wordify
//
//  Created by Lukas Riethig on 31.01.24.
//

import SwiftUI
import SwiftData

struct RichtigOderFalsch: View {
    
    
    var liste: Liste
    init(liste: Liste) {
        self.liste = liste
    }
    
    @Environment(\.modelContext) private var modelContext
    

    
    
    public var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(liste.liste) { vliste in
                        HStack {
                            Text(vliste.vokabelL)
                            Spacer()
                            Text(vliste.vokabelR)
                        }
                        
                    }
                }
                
                
                
                Text("Hello World")
                    .bold()
                    .font(.title)
                   
                    Divider()
                
                Text("Hallo Welt")
                    .font(.title)
                
                HStack {
                    Button(action: {
                        
                    }, label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 60))
                            .foregroundStyle(Color.red)
                            .padding(.horizontal, 50)
                    })
                    
                    Button(action: {
                        
                    }, label: {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 60))
                            .foregroundStyle(Color.green)
                            .padding(.horizontal, 50)
                    })
                }.padding(.top, 50)
            }.navigationTitle("Richtig oder Falsch")
        }
    }
}

/*
#Preview {
    RichtigOderFalsch(liste: liste)
}
*/
