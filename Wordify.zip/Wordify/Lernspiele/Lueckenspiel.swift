//
//  Lückenspiel.swift
//  Wordify
//
//  Created by Lukas Riethig on 31.01.24.
//

import SwiftUI

struct Lueckenspiel: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Lueckenspiel()
}
