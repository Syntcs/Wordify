//
//  Lernspiele.swift
//  Wordify
//
//  Created by Lukas Riethig on 29.01.24.
//

import SwiftUI

struct Lernspiele: View {
    
    //@State var index: Int = 2 // Beispielwert
    
    var body: some View {
        NavigationStack {
        VStack {
            ScrollView {
                NavigationLink(destination: Lernspiel_ListAuswahl(index: 1), label: {
                    VStack {
                        Text("Richtig oder Falsch")
                            .bold()
                            .foregroundStyle(Color.black)
                            .padding(EdgeInsets(top: 10, leading: 0, bottom: 0, trailing: 200))
                        
                        Text("In diesem Spiel erhälst du zu jeder Vokabel")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 14)
                            .foregroundStyle(Color(UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 0.7)))
                        Text("eine Übersetzung.")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 14)
                            .foregroundStyle(Color(UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 0.7)))
                        Text("Du entscheidest: Ist sie richtig oder falsch?")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 14)
                            .foregroundStyle(Color(UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 0.7)))
                        
                        HStack {
                            Text("Spiel starten")
                                .foregroundStyle(Color.blue)
                                .bold()
                            Image(systemName: "chevron.right")
                                .foregroundStyle(Color.blue)
                                .padding(EdgeInsets(top: 10, leading: 0, bottom: 10, trailing: 0))
                                .bold()
                        }
                    }
                })
                .frame(minWidth: 380, maxWidth: 380, minHeight: 100)
                .background(Color(red: 0.9, green: 0.9, blue: 0.9))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                
                NavigationLink(destination: Lernspiel_ListAuswahl(index: 2), label: {
                    VStack {
                        Text("Lückenspiel")
                            .bold()
                            .foregroundStyle(Color.black)
                            .padding(EdgeInsets(top: 10, leading: 0, bottom: 0, trailing: 260))
                        
                        Text("Du erhälst eine Vokabel und die Übersetzung.")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 14)
                            .foregroundStyle(Color(UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 0.7)))
                        Text("Die Übersetzung enthält Lücken.")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 14)
                            .foregroundStyle(Color(UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 0.7)))
                        Text("Kannst du die Lücken richtig füllen?")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 14)
                            .foregroundStyle(Color(UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 0.7)))
                        
                        HStack {
                            Text("Spiel starten")
                                .foregroundStyle(Color.blue)
                                .bold()
                            Image(systemName: "chevron.right")
                                .foregroundStyle(Color.blue)
                                .padding(EdgeInsets(top: 10, leading: 0, bottom: 10, trailing: 0))
                                .bold()
                        }
                        
                    }
                })
                .frame(minWidth: 380, maxWidth: .infinity, minHeight: 100)
                .background(Color(red: 0.9, green: 0.9, blue: 0.9))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .padding(EdgeInsets(top: 5, leading: 50, bottom: 0, trailing: 50))
                
                NavigationLink(destination: Lernspiel_ListAuswahl(index: 3), label: {
                    VStack {
                        Text("Multiple Choice")
                            .bold()
                            .foregroundStyle(Color.black)
                            .padding(EdgeInsets(top: 10, leading: 0, bottom: 0, trailing: 230))
                        Text("Hier erwarten dich mehrere Vokabelpaare,")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 14)
                            .foregroundStyle(Color(UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 0.7)))
                        Text("bestehend aus einem Wort und seiner")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 14)
                            .foregroundStyle(Color(UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 0.7)))
                        Text("Übersetzung. Kannst du sie ausfindig machen?")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 14)
                            .foregroundStyle(Color(UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 0.7)))
                        
                        HStack {
                            Text("Spiel starten")
                                .foregroundStyle(Color.blue)
                                .bold()
                            Image(systemName: "chevron.right")
                                .foregroundStyle(Color.blue)
                                .padding(EdgeInsets(top: 10, leading: 0, bottom: 10, trailing: 0))
                                .bold()
                        }
                        
                    }
                })
                .frame(minWidth: 380, maxWidth: .infinity, minHeight: 100)
                .background(Color(red: 0.9, green: 0.9, blue: 0.9))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .padding(EdgeInsets(top: 5, leading: 50, bottom: 0, trailing: 50))
                
                NavigationLink(destination: Lernspiel_ListAuswahl(index: 4), label: {
                    VStack {
                        Text("Zeitspiel")
                            .bold()
                            .foregroundStyle(Color.black)
                            .padding(EdgeInsets(top: 10, leading: 0, bottom: 0, trailing: 285))
                        
                        Text("Du erhälst zu jeder Vokabel mehrere ")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 14)
                            .foregroundStyle(Color(UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 0.7)))
                        Text("Übersetzungen. Wähle innerhalb von 3 ")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 14)
                            .foregroundStyle(Color(UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 0.7)))
                        Text("Sekunden die passende Vokabel aus.")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 15)
                            .foregroundStyle(Color(UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 0.7)))
                        
                        HStack {
                            Text("Spiel starten")
                                .foregroundStyle(Color.blue)
                                .bold()
                            Image(systemName: "chevron.right")
                                .foregroundStyle(Color.blue)
                                .padding(EdgeInsets(top: 10, leading: 0, bottom: 10, trailing: 0))
                                .bold()
                        }
                        
                    }
                })
                .frame(minWidth: 380, maxWidth: .infinity, minHeight: 100)
                .background(Color(red: 0.9, green: 0.9, blue: 0.9))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .padding(EdgeInsets(top: 10, leading: 50, bottom: 0, trailing: 50))
                
                
                NavigationLink(destination: Lernspiel_ListAuswahl(index: 5), label: {
                    VStack {
                        Text("Vokabeltest")
                            .bold()
                            .foregroundStyle(Color.black)
                            .padding(EdgeInsets(top: 10, leading: 0, bottom: 0, trailing: 260))
                        
                        Text("Hier stellst du dein Können unter Beweis. Gib")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 14)
                            .foregroundStyle(Color(UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 0.7)))
                        Text("nach und nach zu jedem Wort die passende")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 14)
                            .foregroundStyle(Color(UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 0.7)))
                        Text("Übersetzung ein. Am Ende erhälst du eine Note.")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 14)
                            .foregroundStyle(Color(UIColor(red: 25/255, green: 25/255, blue: 25/255, alpha: 0.7)))
                        
                        HStack {
                            Text("Spiel starten")
                                .foregroundStyle(Color.blue)
                                .bold()
                            Image(systemName: "chevron.right")
                                .foregroundStyle(Color.blue)
                                .padding(EdgeInsets(top: 10, leading: 0, bottom: 10, trailing: 0))
                                .bold()
                        }
                        
                    }
                })
                .frame(minWidth: 380, maxWidth: .infinity, minHeight: 100)
                .background(Color(red: 0.9, green: 0.9, blue: 0.9))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .padding(EdgeInsets(top: 5, leading: 50, bottom: 40, trailing: 50))
            }.navigationTitle("Lernspiele")
            
            }
        }
    }
}

#Preview {
    Lernspiele()
}
