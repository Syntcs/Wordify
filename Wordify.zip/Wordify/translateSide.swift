//
//  translateSide.swift
//  VocabHub
//
//  Created by Lukas Riethig on 22.09.23.
//

import SwiftUI



struct translateSide: View {
    
    
    
    
    @State private var inputText = ""
    @State private var translatedText = ""
    

    
    let languages = ["Deutsch", "Englisch", "Französisch", "Spanisch"]
    @AppStorage("Sprache") private var selection = "Englisch"
    @AppStorage("isDarkMode") private var isDarkMode = false
    @State var DarkMode: Bool = false
    
    @State private var StarButton = false
    @State private var SpeakerButton = false
    
    @FocusState var isFocus: Bool

    
    @State var translation = "Übersetzung"
    
    
    
    var body: some View {
        ZStack {
            NavigationStack {
                VStack {
                    HStack {
                        Text("Wordify").font(.largeTitle).bold()
                        Spacer()
                        Button(action: {
                            DarkMode.toggle()
                        }, label: {
                            Image(systemName: "gear")
                                .font(.system(size: 25))
                        })
                    }.padding(.horizontal, 10).padding(.top, 10)
                    Divider()
                    TextField("Text eingeben", text: $inputText, axis: .vertical)
                        .font(.system(size: 25))
                        .frame(minHeight: 100, maxHeight: 200, alignment: .topLeading)
                        .padding(.horizontal, 10)
                        .disableAutocorrection(true)
                        .multilineTextAlignment(.leading)
                        .focused($isFocus)
                    
                    Button(action: {
                        translateText()
                    }, label: {
                        Image(systemName: "arrow.right")
                            .foregroundStyle(Color.white)
                            .font(.system(size: 25))
                            .padding(15)
                            .background(Color.blue)
                            .clipShape(Circle())
                            .bold()
                    }).frame(maxWidth: .infinity, alignment: .trailing).padding(.horizontal, 15)
                    
                    
                    Divider()
                    
                    
                    Picker("Sprache", selection: $selection) {
                        ForEach(languages, id: \.self) {
                            Text($0)
                        }
                    }
                    .pickerStyle(.menu)
                    
                    ZStack {
                        if translatedText == "" {
                            Text("Übersetzung")
                                .foregroundStyle(Color.gray)
                                .font(.system(size: 25))
                                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                                .padding(.leading, 20)
                                .padding(.top, 20)
                        }
                        ScrollView {
                            Text ("\(translatedText)")
                                .font(.system(size: 25))
                                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                                .padding(.leading, 20)
                                .padding(.top, 20)
                                .lineLimit(nil)
                        }
                    }
                    HStack {
                        if StarButton == false {
                            Button(action: {
                                StarButton.toggle()
                            }, label: {
                                Image(systemName: "star")
                                    .foregroundStyle(Color.white)
                                    .font(.system(size: 22))
                                    .padding(15)
                                    .background(Color.blue)
                                    .clipShape(Circle())
                                    .bold()
                            }).frame(maxWidth: .infinity, alignment: .trailing).padding(.horizontal, 15)
                        } else {
                            Button(action: {
                                StarButton.toggle()
                            }, label: {
                                Image(systemName: "star.fill")
                                    .foregroundStyle(Color.white)
                                    .font(.system(size: 22))
                                    .padding(15)
                                    .background(Color.blue)
                                    .clipShape(Circle())
                                    .bold()
                            })
                        }
                    }
                    Divider()
                }.onTapGesture {
                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                }.preferredColorScheme(isDarkMode ? .dark : .light)
            }
        }.sheet(isPresented: $DarkMode, content: {
            Settings()
                .presentationDetents([.height(300)])
                .presentationBackground(.clear)
        }).onTapGesture {
            isFocus = false
        }
    }
    


    func translateText() {
        if apiKey.isEmpty {
            print("DeepL API-Schlüssel fehlt.")
            return
        }
        
        var targetLanguage = ""
        
        if selection == "Englisch" {
            targetLanguage = "EN"
        } else if selection == "Französisch" {
            targetLanguage = "FR"
        } else if selection == "Spanisch" {
            targetLanguage = "ES"
        } else {
            targetLanguage = "DE"
        }
        
        let endpoint = "https://api-free.deepl.com/v2/translate"
        let authHeader = "DeepL-Auth-Key \(apiKey)"
        let textParameter = "text=\(inputText.lowercased().addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")"
        let targetLangParameter = "target_lang=\(targetLanguage)"
        
        guard let url = URL(string: endpoint) else {
            print("Ungültige URL.")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue(authHeader, forHTTPHeaderField: "Authorization")
        request.httpBody = "\(textParameter)&\(targetLangParameter)".data(using: .utf8)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Fehler bei der Anfrage: \(error.localizedDescription)")
            } else if let data = data {
                do {
                    let decodedResponse = try JSONDecoder().decode(DeepLResponse.self, from: data)
                    translatedText = decodedResponse.translations.first?.text ?? "Übersetzung nicht verfügbar"
                } catch {
                    print("Fehler beim Dekodieren der API-Antwort: \(error.localizedDescription)")
                }
            }
        }.resume()
    }
    
    
    struct DeepLResponse: Decodable {
        struct Translation: Decodable {
            var detected_source_language: String
            var text: String
        }
        
        var translations: [Translation]
    }
}

#Preview {
    translateSide()
}
