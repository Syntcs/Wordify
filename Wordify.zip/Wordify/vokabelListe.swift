import SwiftUI
import SwiftData

public struct vokabelListe: View {

    var liste: Liste
    init(liste: Liste) {
        self.liste = liste
    }
    
    @Environment(\.modelContext) private var modelContext
    
    @State private var vokabelL = ""
    @State private var vokabelR = ""
    
    public var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(liste.liste) { vliste in
                        HStack {
                            Text(vliste.vokabelL)
                            Spacer()
                            Text(vliste.vokabelR)
                        }
                        
                    }
                    .onDelete(perform: deleteVokabeln)
                }
                
                Spacer()
                HStack {
                    TextField("Vokabel", text: $vokabelL)
                    TextField("Vokabel", text: $vokabelR)
                    
                    Button(action: {
                        let insert = vListe(vokabelL: vokabelL, vokabelR: vokabelR)
                        liste.liste.append(insert)
                        vokabelL = ""
                        vokabelR = ""
                    }) {
                        ZStack {
                            Circle()
                                .fill(Color.blue)
                                .frame(width: 50, height: 50)
                            
                            Image(systemName: "plus")
                                .foregroundColor(.white)
                        }
                    }
                    
                }
                .padding(.horizontal)
            }
        }
        .navigationTitle("Vokabelliste")
    }
    
    private func deleteVokabeln(indexSet: IndexSet) {
        for index in indexSet {
            let liste = liste.liste.remove(at: index)
            modelContext.delete(liste)
        }
    }
}
/*
#Preview {
    vokabelListe(liste: Liste(name: "Name", datum: "02.02.2024"))
        .environment(\.locale, Locale(identifier: "de_DE"))
        .modelContainer(for: [Liste.self, vListe.self], inMemory: true)
}*/

